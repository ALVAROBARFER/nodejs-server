const express = require("express");
const app = express();

const port = 8000;

/*app.listen(port, function(){
    console.log("Servidor desplegado en " + port)
})

app.get('/', function(peticion, respuesta){

    respuesta.send("hola")
})*/

app.get('/', function(peticion, respuesta){

    respuesta.json({nombre: "Jhon"});
    
});

app.get('/Datos', function(peticion, respuesta){
    respuesta.send("Datos");
});

app.get('/html', function(peticion, respuesta){
    respuesta.sendFile(__dirname + "/views/index.html");
});

app.post('/', function(peticion, respuesta){
    respuesta.json(peticion);
});



app.listen(port, () =>{
    console.log('Servidor desplegado en '+ port)
})